-- nerf cabbage: longer growth time
--
--
-- by razab



farming_vegetableconf.props["Cabbages"].timeToGrow = ZombRand(89, 103);
--farming_vegetableconf.props["Carrots"].timeToGrow = ZombRand(50,55);
--farming_vegetableconf.props["Broccoli"].timeToGrow = ZombRand(103, 117);
--farming_vegetableconf.props["Radishes"].timeToGrow = ZombRand(56, 62);
--farming_vegetableconf.props["Strawberry plant"].timeToGrow = ZombRand(103, 131);
--farming_vegetableconf.props["Tomato"].timeToGrow = ZombRand(89, 103);
--farming_vegetableconf.props["Potatoes"].timeToGrow = ZombRand(89, 103);


